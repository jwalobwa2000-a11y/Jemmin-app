# Jemmin client app (APK)

1. Create a new empty repository on github.com (private is fine).
2. Upload everything in this folder, including the hidden `.github` folder and the `assets` folder.
3. Open the repository's Actions tab. The "Build Jemmin APK" run starts by itself (about 5 to 8 minutes).
4. When it finishes, open the run, download `jemmin-apk` from Artifacts, unzip it and install `app-debug.apk` on your phone.
   Android will ask you to allow installs from your browser or file manager.

The phone icon and launch screen are made from the logo in `assets/`.
To change the app, edit `www/index.html` and push. A new APK is built each time.
